import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

import '../services/order_service.dart';
import '../theme/fratheli_colors.dart';
import '../utils/formatters.dart';
import 'widgets/premium_app_bar.dart';

class MeusPedidosPage extends StatefulWidget {
  const MeusPedidosPage({super.key});

  @override
  State<MeusPedidosPage> createState() => _MeusPedidosPageState();
}

class _MeusPedidosPageState extends State<MeusPedidosPage> {
  late Future<List<Map<String, dynamic>>> _future;

  @override
  void initState() {
    super.initState();
    _future = OrderService.fetchMyOrders();
  }

  void _refresh() {
    setState(() => _future = OrderService.fetchMyOrders());
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: FratheliColors.paper,
      appBar: PremiumAppBar(
        actions: [
          IconButton(
            tooltip: 'Atualizar pedidos',
            onPressed: _refresh,
            icon: const Icon(Icons.refresh),
          ),
          const SizedBox(width: 10),
        ],
      ),
      body: Center(
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 1040),
          child: FutureBuilder<List<Map<String, dynamic>>>(
            future: _future,
            builder: (context, snapshot) {
              if (snapshot.connectionState == ConnectionState.waiting) {
                return const Center(child: CircularProgressIndicator());
              }
              if (snapshot.hasError) {
                return _MessageState(
                  icon: Icons.receipt_long_outlined,
                  title: 'Não foi possível carregar seus pedidos',
                  message: snapshot.error.toString().replaceFirst('Exception: ', ''),
                  button: 'Tentar novamente',
                  onTap: _refresh,
                );
              }
              final orders = snapshot.data ?? const <Map<String, dynamic>>[];
              return RefreshIndicator(
                onRefresh: () async => _refresh(),
                child: ListView(
                  padding: const EdgeInsets.fromLTRB(20, 46, 20, 60),
                  children: [
                    const _Eyebrow('ÁREA DO CLIENTE'),
                    Text(
                      'Meus pedidos',
                      style: GoogleFonts.libreCaslonDisplay(
                        color: FratheliColors.ink,
                        fontSize: 52,
                        height: 1,
                      ),
                    ),
                    const SizedBox(height: 12),
                    const Text(
                      'Acompanhe o pagamento, a preparação e a entrega dos seus cafés.',
                      style: TextStyle(color: FratheliColors.text2, height: 1.5),
                    ),
                    const SizedBox(height: 32),
                    if (orders.isEmpty)
                      _MessageState(
                        icon: Icons.local_cafe_outlined,
                        title: 'Nenhum pedido por aqui',
                        message: 'Quando você finalizar uma compra, o pedido e o status aparecerão nesta tela.',
                        button: 'Escolher cafés',
                        onTap: () => Navigator.pushNamedAndRemoveUntil(context, '/home', (route) => false),
                      )
                    else
                      ...orders.map((order) => _OrderCard(order: order)),
                  ],
                ),
              );
            },
          ),
        ),
      ),
    );
  }
}

class _OrderCard extends StatelessWidget {
  final Map<String, dynamic> order;
  const _OrderCard({required this.order});

  @override
  Widget build(BuildContext context) {
    final code = _pick(order, ['order_code', 'id'], fallback: '—');
    final created = _pick(order, ['created_at', 'createdAt'], fallback: '');
    final total = _number(order['total']).toDouble();
    final payment = _status(
      _pick(order, ['paymentStatus', 'payment_status']),
      shipping: false,
    );
    final shipping = _status(
      _pick(order, ['shippingStatus', 'shipping_status']),
      shipping: true,
    );

    return Padding(
      padding: const EdgeInsets.only(bottom: 14),
      child: Material(
        color: Colors.white,
        child: InkWell(
          onTap: () => Navigator.pushNamed(context, '/pedido', arguments: code),
          child: Container(
            padding: const EdgeInsets.all(22),
            decoration: BoxDecoration(border: Border.all(color: FratheliColors.border)),
            child: LayoutBuilder(
              builder: (context, constraints) {
                final compact = constraints.maxWidth < 620;
                final heading = Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('PEDIDO', style: GoogleFonts.dmSans(color: FratheliColors.cherry, fontSize: 10, fontWeight: FontWeight.w700, letterSpacing: 1.7)),
                    const SizedBox(height: 4),
                    Text(code, style: GoogleFonts.libreCaslonDisplay(fontSize: 27)),
                    if (created.isNotEmpty) ...[
                      const SizedBox(height: 5),
                      Text(_date(created), style: const TextStyle(color: FratheliColors.muted, fontSize: 12)),
                    ],
                  ],
                );
                final details = Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Wrap(spacing: 8, runSpacing: 8, children: [
                      _StatusPill(label: 'Pagamento: ${payment.label}', icon: payment.icon, color: payment.color),
                      _StatusPill(label: 'Entrega: ${shipping.label}', icon: shipping.icon, color: shipping.color),
                    ]),
                    const SizedBox(height: 14),
                    Row(
                      children: [
                        Text(brl(total), style: GoogleFonts.libreCaslonDisplay(fontSize: 25)),
                        const Spacer(),
                        const Text('Ver pedido', style: TextStyle(color: FratheliColors.cherry, fontWeight: FontWeight.w700)),
                        const SizedBox(width: 4),
                        const Icon(Icons.arrow_forward, size: 17, color: FratheliColors.cherry),
                      ],
                    ),
                  ],
                );
                if (compact) {
                  return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [heading, const SizedBox(height: 18), details]);
                }
                return Row(children: [SizedBox(width: 245, child: heading), Expanded(child: details)]);
              },
            ),
          ),
        ),
      ),
    );
  }
}

class _StatusPill extends StatelessWidget {
  final String label;
  final IconData icon;
  final Color color;
  const _StatusPill({required this.label, required this.icon, required this.color});
  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
        decoration: BoxDecoration(
          color: color.withOpacity(.10),
          border: Border.all(color: color.withOpacity(.25)),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, size: 14, color: color),
            const SizedBox(width: 6),
            Text(label, style: TextStyle(color: color, fontSize: 11, fontWeight: FontWeight.w700)),
          ],
        ),
      );
}

class _MessageState extends StatelessWidget {
  final IconData icon;
  final String title;
  final String message;
  final String button;
  final VoidCallback onTap;
  const _MessageState({required this.icon, required this.title, required this.message, required this.button, required this.onTap});
  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.all(34),
        decoration: BoxDecoration(color: FratheliColors.cream, border: Border.all(color: FratheliColors.border)),
        child: Column(
          children: [
            Icon(icon, size: 42, color: FratheliColors.cherry),
            const SizedBox(height: 15),
            Text(title, textAlign: TextAlign.center, style: GoogleFonts.libreCaslonDisplay(fontSize: 31)),
            const SizedBox(height: 8),
            Text(message, textAlign: TextAlign.center, style: const TextStyle(color: FratheliColors.text2, height: 1.5)),
            const SizedBox(height: 20),
            ElevatedButton(onPressed: onTap, child: Text(button)),
          ],
        ),
      );
}

class _Eyebrow extends StatelessWidget {
  final String text;
  const _Eyebrow(this.text);
  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.only(bottom: 12),
        child: Text(text, style: GoogleFonts.dmSans(color: FratheliColors.cherry, fontSize: 10, fontWeight: FontWeight.w700, letterSpacing: 1.8)),
      );
}

({String label, IconData icon, Color color}) _status(String raw, {required bool shipping}) {
  final value = raw.toUpperCase().trim();
  if (value.contains('CANCEL') || value.contains('REJEIT')) {
    return (label: 'Cancelado', icon: Icons.cancel_outlined, color: FratheliColors.danger);
  }
  if (!shipping && (value.contains('PAGO') || value.contains('APROV'))) {
    return (label: 'Pago', icon: Icons.check_circle_outline, color: FratheliColors.green);
  }
  if (shipping && (value.contains('ENTREG') || value.contains('CONCLU'))) {
    return (label: 'Entregue', icon: Icons.home_outlined, color: FratheliColors.green);
  }
  if (shipping && value.contains('AGUARD') && value.contains('ENVI')) {
    return (label: 'Aguardando envio', icon: Icons.schedule, color: FratheliColors.gold);
  }
  if (shipping && (value.startsWith('ENVIADO') || value.contains('POSTADO') || value.contains('EM_TRANSPORTE'))) {
    return (label: 'Enviado', icon: Icons.local_shipping_outlined, color: FratheliColors.cherry);
  }
  if (shipping && (value.contains('PREPAR') || value.contains('SEPAR'))) {
    return (label: 'Em preparação', icon: Icons.inventory_2_outlined, color: FratheliColors.gold);
  }
  return (
    label: shipping ? 'Aguardando pagamento' : 'Aguardando pagamento',
    icon: Icons.schedule,
    color: FratheliColors.gold,
  );
}

String _pick(Map<String, dynamic> map, List<String> keys, {String fallback = '-'}) {
  for (final key in keys) {
    final value = map[key];
    if (value != null && value.toString().trim().isNotEmpty) return value.toString().trim();
  }
  return fallback;
}

num _number(dynamic value) {
  if (value is num) return value;
  return num.tryParse((value ?? '0').toString().replaceAll(',', '.')) ?? 0;
}

String _date(String raw) {
  try {
    final value = DateTime.parse(raw.replaceFirst(' ', 'T'));
    String two(int n) => n.toString().padLeft(2, '0');
    return '${two(value.day)}/${two(value.month)}/${value.year} · ${two(value.hour)}:${two(value.minute)}';
  } catch (_) {
    return raw;
  }
}
