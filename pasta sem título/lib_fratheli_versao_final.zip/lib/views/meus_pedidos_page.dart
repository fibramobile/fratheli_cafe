import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

import '../services/order_service.dart';
import '../theme/fratheli_colors.dart';

class MeusPedidosPage extends StatefulWidget {
  const MeusPedidosPage({super.key});

  @override
  State<MeusPedidosPage> createState() => _MeusPedidosPageState();
}

class _MeusPedidosPageState extends State<MeusPedidosPage> {
  static const _paymentBase =
      'https://frathelicafe.com.br/pagamento_order.html?orderId=';

  late Future<List<Map<String, dynamic>>> _future;

  @override
  void initState() {
    super.initState();
    _future = OrderService.fetchMyOrders();
  }

  void _reload() {
    setState(() => _future = OrderService.fetchMyOrders());
  }

  String _brl(num value) =>
      'R\$ ${value.toStringAsFixed(2).replaceAll('.', ',')}';

  num _parseNum(dynamic value) {
    if (value is num) return value;
    return num.tryParse((value ?? '0').toString().replaceAll(',', '.')) ?? 0;
  }

  String _formatDate(String raw) {
    try {
      final date = DateTime.parse(raw.replaceFirst(' ', 'T'));
      String two(int value) => value.toString().padLeft(2, '0');
      return '${two(date.day)}/${two(date.month)}/${date.year} · '
          '${two(date.hour)}:${two(date.minute)}';
    } catch (_) {
      return raw.isEmpty ? 'Data não informada' : raw;
    }
  }

  String _pick(Map<String, dynamic> order, List<String> keys,
      {String fallback = ''}) {
    for (final key in keys) {
      final value = order[key];
      if (value == null) continue;
      final text = value.toString().trim();
      if (text.isNotEmpty) return text;
    }
    return fallback;
  }

  _OrderStatus _status(String raw, {required bool payment}) {
    final value = raw.toUpperCase().trim();

    if (value.contains('CANCEL') || value.contains('REJEIT')) {
      return const _OrderStatus(
        'Cancelado',
        Icons.cancel_outlined,
        FratheliColors.danger,
        Color(0x1AA12F21),
      );
    }
    if (payment && (value.contains('PAGO') || value.contains('APROV'))) {
      return const _OrderStatus(
        'Pago',
        Icons.check_circle_outline,
        FratheliColors.green,
        Color(0x1F42724F),
      );
    }
    if (!payment &&
        (value.contains('ENTREG') || value.contains('CONCLU'))) {
      return const _OrderStatus(
        'Entregue',
        Icons.task_alt,
        FratheliColors.green,
        Color(0x1F42724F),
      );
    }
    if (!payment &&
        (value.contains('ENVI') ||
            value.contains('POST') ||
            value.contains('TRANSP'))) {
      return const _OrderStatus(
        'Enviado',
        Icons.local_shipping_outlined,
        FratheliColors.blue,
        Color(0x1F46718B),
      );
    }
    if (!payment &&
        (value.contains('PREPAR') || value.contains('SEPAR'))) {
      return const _OrderStatus(
        'Preparando pedido',
        Icons.inventory_2_outlined,
        FratheliColors.gold,
        Color(0x22C89A45),
      );
    }
    return const _OrderStatus(
      'Aguardando pagamento',
      Icons.schedule,
      FratheliColors.gold,
      Color(0x22C89A45),
    );
  }

  bool _canPay(String raw) {
    final value = raw.toUpperCase();
    return !value.contains('PAGO') &&
        !value.contains('APROV') &&
        !value.contains('CANCEL') &&
        !value.contains('REJEIT');
  }

  Future<void> _openPayment(String code) async {
    final uri = Uri.parse('$_paymentBase${Uri.encodeComponent(code)}');
    final opened = await launchUrl(
      uri,
      mode: kIsWeb ? LaunchMode.platformDefault : LaunchMode.externalApplication,
    );
    if (!opened && mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Não foi possível abrir o pagamento.')),
      );
    }
  }

  Widget _statusTile(String title, _OrderStatus status) {
    return Container(
      constraints: const BoxConstraints(minWidth: 190),
      padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 11),
      decoration: BoxDecoration(
        color: status.background,
        border: Border.all(color: status.color.withOpacity(0.2)),
        borderRadius: BorderRadius.circular(2),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(status.icon, size: 19, color: status.color),
          const SizedBox(width: 9),
          Flexible(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title.toUpperCase(),
                  style: const TextStyle(
                    color: FratheliColors.textMuted,
                    fontSize: 9,
                    fontWeight: FontWeight.w800,
                    letterSpacing: 1.1,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  status.label,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    color: FratheliColors.text,
                    fontSize: 12,
                    fontWeight: FontWeight.w800,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _orderCard(Map<String, dynamic> order) {
    final code = _pick(
      order,
      const ['order_code', 'id', 'orderId', 'order_id'],
      fallback: 'Pedido',
    );
    final paymentRaw = _pick(
      order,
      const ['paymentStatus', 'payment_status'],
    );
    final shippingRaw = _pick(
      order,
      const ['shippingStatus', 'shipping_status'],
    );
    final payment = _status(paymentRaw, payment: true);
    final shipping = _status(shippingRaw, payment: false);
    final date = _formatDate(
      _pick(order, const ['created_at', 'createdAt']),
    );
    final total = _parseNum(order['total']);

    return Container(
      margin: const EdgeInsets.only(bottom: 14),
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: FratheliColors.surface,
        border: Border.all(color: FratheliColors.border),
        borderRadius: BorderRadius.circular(2),
        boxShadow: const [
          BoxShadow(
            color: Color(0x0D2C1C13),
            blurRadius: 28,
            offset: Offset(0, 12),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Pedido #$code',
                      style: Theme.of(context).textTheme.titleLarge?.copyWith(
                            fontSize: 24,
                            color: FratheliColors.text,
                          ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      date,
                      style: const TextStyle(
                        color: FratheliColors.textMuted,
                        fontSize: 12,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 12),
              Text(
                _brl(total),
                style: Theme.of(context).textTheme.titleLarge?.copyWith(
                      fontSize: 22,
                      color: FratheliColors.brown,
                    ),
              ),
            ],
          ),
          const SizedBox(height: 17),
          Wrap(
            spacing: 10,
            runSpacing: 10,
            children: [
              _statusTile('Pagamento', payment),
              _statusTile('Entrega', shipping),
            ],
          ),
          const SizedBox(height: 16),
          const Divider(height: 1, color: FratheliColors.border),
          const SizedBox(height: 14),
          Wrap(
            alignment: WrapAlignment.end,
            spacing: 10,
            runSpacing: 10,
            children: [
              OutlinedButton.icon(
                onPressed: () => Navigator.pushNamed(
                  context,
                  '/pedido',
                  arguments: code,
                ),
                icon: const Icon(Icons.receipt_long_outlined, size: 18),
                label: const Text('Ver pedido'),
              ),
              if (_canPay(paymentRaw))
                ElevatedButton.icon(
                  onPressed: () => _openPayment(code),
                  icon: const Icon(Icons.pix, size: 18),
                  label: const Text('Pagar com Pix'),
                ),
            ],
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final width = MediaQuery.sizeOf(context).width;
    final sidePadding = width >= 900 ? 28.0 : 16.0;

    return Scaffold(
      backgroundColor: FratheliColors.bg2,
      appBar: AppBar(
        toolbarHeight: 88,
        backgroundColor: FratheliColors.brown,
        foregroundColor: FratheliColors.cream,
        surfaceTintColor: Colors.transparent,
        titleSpacing: 8,
        title: Row(
          children: [
            Image.asset(
              'assets/img/logo_branco.png',
              width: 106,
              height: 72,
              fit: BoxFit.contain,
            ),
            const SizedBox(width: 12),
            const Text(
              'Meus pedidos',
              style: TextStyle(fontSize: 17, fontWeight: FontWeight.w700),
            ),
          ],
        ),
        actions: [
          IconButton(
            tooltip: 'Atualizar pedidos',
            onPressed: _reload,
            icon: const Icon(Icons.refresh),
          ),
          const SizedBox(width: 10),
        ],
        bottom: const PreferredSize(
          preferredSize: Size.fromHeight(1),
          child: Divider(height: 1, color: Color(0x44E2B85C)),
        ),
      ),
      body: Center(
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 1040),
          child: FutureBuilder<List<Map<String, dynamic>>>(
            future: _future,
            builder: (context, snapshot) {
              if (snapshot.connectionState == ConnectionState.waiting) {
                return const Center(child: CircularProgressIndicator());
              }

              if (snapshot.hasError) {
                return _OrdersMessage(
                  icon: Icons.cloud_off_outlined,
                  title: 'Não foi possível carregar',
                  message: snapshot.error.toString(),
                  buttonLabel: 'Tentar novamente',
                  onPressed: _reload,
                );
              }

              final orders = snapshot.data ?? const <Map<String, dynamic>>[];
              if (orders.isEmpty) {
                return _OrdersMessage(
                  icon: Icons.local_cafe_outlined,
                  title: 'Nenhum pedido ainda',
                  message:
                      'Quando você fizer uma compra, ela aparecerá aqui com o status atualizado.',
                  buttonLabel: 'Escolher um café',
                  onPressed: () => Navigator.pushNamed(context, '/home'),
                );
              }

              return RefreshIndicator(
                onRefresh: () async {
                  _reload();
                  await _future;
                },
                child: ListView.builder(
                  padding: EdgeInsets.fromLTRB(
                    sidePadding,
                    30,
                    sidePadding,
                    34,
                  ),
                  itemCount: orders.length + 1,
                  itemBuilder: (context, index) {
                    if (index == 0) {
                      return Padding(
                        padding: const EdgeInsets.only(bottom: 22),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text(
                              'ÁREA DO CLIENTE',
                              style: TextStyle(
                                color: FratheliColors.cherry,
                                fontSize: 11,
                                fontWeight: FontWeight.w800,
                                letterSpacing: 2,
                              ),
                            ),
                            const SizedBox(height: 10),
                            Text(
                              'Acompanhe seus pedidos',
                              style: Theme.of(context)
                                  .textTheme
                                  .headlineMedium
                                  ?.copyWith(fontSize: width < 600 ? 34 : 46),
                            ),
                            const SizedBox(height: 8),
                            const Text(
                              'Veja pagamento, preparo, frete e entrega em um só lugar.',
                              style: TextStyle(color: FratheliColors.textMuted),
                            ),
                          ],
                        ),
                      );
                    }
                    return _orderCard(orders[index - 1]);
                  },
                ),
              );
            },
          ),
        ),
      ),
    );
  }
}

class _OrderStatus {
  final String label;
  final IconData icon;
  final Color color;
  final Color background;

  const _OrderStatus(this.label, this.icon, this.color, this.background);
}

class _OrdersMessage extends StatelessWidget {
  final IconData icon;
  final String title;
  final String message;
  final String buttonLabel;
  final VoidCallback onPressed;

  const _OrdersMessage({
    required this.icon,
    required this.title,
    required this.message,
    required this.buttonLabel,
    required this.onPressed,
  });

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(28),
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 440),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(icon, size: 46, color: FratheliColors.gold),
              const SizedBox(height: 16),
              Text(
                title,
                textAlign: TextAlign.center,
                style: Theme.of(context)
                    .textTheme
                    .titleLarge
                    ?.copyWith(fontSize: 29),
              ),
              const SizedBox(height: 9),
              Text(
                message,
                textAlign: TextAlign.center,
                style: const TextStyle(color: FratheliColors.textMuted),
              ),
              const SizedBox(height: 20),
              ElevatedButton(onPressed: onPressed, child: Text(buttonLabel)),
            ],
          ),
        ),
      ),
    );
  }
}
