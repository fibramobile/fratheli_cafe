import 'package:flutter/material.dart';

class FratheliColors {
  // Paleta premium da versão final do site.
  static const bg = Color(0xFFF4EFE6);
  static const bg2 = Color(0xFFFDFBF7);

  // Superfícies / cards
  static const surface = Color(0xFFFFFFFF);
  static const surfaceAlt = Color(0xFFF4EFE6);

  // Bordas / divisórias
  static const border = Color(0x241D1713);

  // Textos
  static const text = Color(0xFF1D1713);
  static const text2 = Color(0xFF5D534B);
  static const text3 = Color(0xFF8E8278);
  static const textMuted = Color(0xFF746A61);

  // Marca (dourados Frathéli)
  static const gold = Color(0xFFC89A45);
  static const gold2 = Color(0xFFE2B85C);
  static const brown = Color(0xFF21150F);
  static const brown2 = Color(0xFF38251A);
  static const cream = Color(0xFFF4EFE6);
  static const cherry = Color(0xFF7C2D20);

  // Estados / ações
  static const green = Color(0xFF42724F);
  static const blue = Color(0xFF46718B);
  static const danger = Color(0xFFA12F21);
}
