import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

class AuthService {
  // ✅ Ajuste para o seu domínio/endpoint
  static const String baseUrl = 'https://frathelicafe.com.br/api';

  static Future<Map<String, dynamic>> login({
    required String email,
    required String password,
  }) async {
    final uri = Uri.parse('$baseUrl/auth/login.php');

    final res = await http.post(
      uri,
      headers: {
        'Content-Type': 'application/json; charset=utf-8',
      },
      body: jsonEncode({
        'email': email.trim(),
        'password': password,
      }),
    );

    final body = safeJson(res.body);

    if (res.statusCode != 200) {
      final msg = (body['error'] ?? 'Falha no login').toString();
      throw Exception(msg);
    }

    // Espera: { token: "...", user: { id, name, email } }
    final token = body['token']?.toString();

    final rawUser = body['user'];

    if (token == null || token.isEmpty || rawUser == null) {
      throw Exception('Resposta inválida do servidor.');
    }

// 👇 transforma em Map editável
    final user = Map<String, dynamic>.from(rawUser);

// 👇 garante que role sempre exista
    user['role'] = (user['role'] ?? 'user').toString();

    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('auth_token', token);
    await prefs.setString('auth_user', jsonEncode(user));

    return {
      'token': token,
      'user': user,
    };
  }

  static Future<void> logout() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove('auth_token');
    await prefs.remove('auth_user');
  }

  static Future<String?> getToken() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString('auth_token');
  }

  static Future<Map<String, dynamic>?> getUser() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString('auth_user');
    if (raw == null) return null;
    return safeJson(raw);
  }

  static Map<String, dynamic> safeJson(String raw) {
    try {
      final decoded = jsonDecode(raw);
      if (decoded is Map<String, dynamic>) return decoded;
      return {};
    } catch (_) {
      return {};
    }
  }

  static Future<Map<String, dynamic>> register({
    required String name,
    required String email,
    required String password,
    String? whatsapp,
  }) async {
    final uri = Uri.parse('$baseUrl/auth/register.php');

    final res = await http.post(
      uri,
      headers: {'Content-Type': 'application/json; charset=utf-8'},
      body: jsonEncode({
        'name': name.trim(),
        'email': email.trim(),
        'password': password,
        'whatsapp': (whatsapp ?? '').trim(),
      }),
    );

    // ✅ DEBUG (mostra o erro real)
    debugPrint('REGISTER status: ${res.statusCode}');
    debugPrint('REGISTER raw body: ${res.body}');

    final body = safeJson(res.body);

    if (res.statusCode != 200) {
      final msg = (body['error'] ?? 'Falha no cadastro').toString();
      throw Exception(msg);
    }

    final token = body['token']?.toString();
    final user = body['user'];

    if (token == null || token.isEmpty || user == null) {
      throw Exception('Resposta inválida do servidor.');
    }

    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('auth_token', token);
    await prefs.setString('auth_user', jsonEncode(user));

    return {'token': token, 'user': user};
  }


  static Future<Map<String, dynamic>> fetchMyAccount() async {
    final token = await getToken();
    if (token == null) throw Exception('Usuário não autenticado');

    // ✅ caminho correto
    final uri = Uri.parse('$baseUrl/account/me.php');

    final res = await http.get(
      uri,
      headers: {
        'Authorization': 'Bearer $token',
        'Content-Type': 'application/json; charset=utf-8',
      },
    );

    debugPrint('ME status: ${res.statusCode}');
    debugPrint('ME raw body: ${res.body}');

    final body = safeJson(res.body);

    if (res.statusCode != 200) {
      final msg = (body['error'] ?? 'Falha ao buscar conta').toString();
      throw Exception(msg);
    }

    return body; // { user: {...}, points: {...} }
  }



  static Future<Map<String, dynamic>?> fetchClientProfile() async {
    final token = await getToken();
    if (token == null) return null;

    final uri = Uri.parse('$baseUrl/account/profile_get.php');
    final res = await http.get(uri, headers: {
      'Authorization': 'Bearer $token',
      'Content-Type': 'application/json; charset=utf-8',
    });

    final body = safeJson(res.body);
    if (res.statusCode != 200) return null;

    return body['profile'];
  }


  static Future<void> upsertClientProfile({
    required String cpf,
    required String phone,
    required Map<String, dynamic> address,
  }) async {
    final token = await getToken();
    if (token == null) throw Exception('Usuário não autenticado');

    final uri = Uri.parse('$baseUrl/account/profile_upsert.php');
    final res = await http.post(
      uri,
      headers: {
        'Authorization': 'Bearer $token',
        'Content-Type': 'application/json; charset=utf-8',
      },
      body: jsonEncode({
        'cpf': cpf,
        'phone': phone,
        'address': address,
      }),
    );

    final body = safeJson(res.body);
    if (res.statusCode != 200) {
      throw Exception((body['error'] ?? 'Falha ao salvar perfil').toString());
    }
  }

  static Future<String> getRole() async {
    try {
      final me = await fetchMyAccount();
      final role = (me['user']?['role'] ?? '').toString().trim();

      if (role.isNotEmpty) {
        // atualiza o cache local também
        final prefs = await SharedPreferences.getInstance();
        final currentUser = await getUser() ?? {};
        currentUser['role'] = role;
        await prefs.setString('auth_user', jsonEncode(currentUser));

        return role;
      }
    } catch (_) {}

    final u = await getUser();
    return (u?['role'] ?? 'user').toString();
  }

  static Future<bool> isAdmin() async {
    final role = await getRole();
    debugPrint('ROLE DETECTADA: $role');
    return role.toLowerCase() == 'admin';
  }


  static Future<void> changePassword({
    required String currentPassword,
    required String newPassword,
  }) async {
    final token = await getToken();
    if (token == null) throw Exception('Usuário não autenticado');

    final uri = Uri.parse('$baseUrl/account/change_password.php');

    final res = await http.post(
      uri,
      headers: {
        'Authorization': 'Bearer $token',
        'Content-Type': 'application/json; charset=utf-8',
      },
      body: jsonEncode({
        'current_password': currentPassword,
        'new_password': newPassword,
      }),
    );

    final body = safeJson(res.body);

    if (res.statusCode != 200) {
      throw Exception((body['error'] ?? 'Falha ao alterar senha').toString());
    }
  }


  static Future<void> updateBasicUser({
    required String name,
  }) async {
    final token = await getToken();
    if (token == null) throw Exception('Usuário não autenticado');

    final uri = Uri.parse('$baseUrl/account/update_user.php');

    final res = await http.post(
      uri,
      headers: {
        'Authorization': 'Bearer $token',
        'Content-Type': 'application/json; charset=utf-8',
      },
      body: jsonEncode({
        'name': name,
      }),
    );

    final body = safeJson(res.body);

    if (res.statusCode != 200) {
      throw Exception((body['error'] ?? 'Falha ao atualizar usuário').toString());
    }

    final prefs = await SharedPreferences.getInstance();
    final currentUser = await getUser() ?? {};
    currentUser['name'] = name;
    await prefs.setString('auth_user', jsonEncode(currentUser));
  }

}
